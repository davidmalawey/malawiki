---
type: concept
aliases: [parametric, parametric CAD, variable-driven design]
tags: [cad, design-philosophy, reusability]
source_count: 3
---

# Parametric design

## Definition

Modeling a part or assembly by exposing key dimensions as named variables, so the design can be re-dimensioned without redrawing. A parametric hinge, for example, keeps its geometric intent (hole positions, wall thickness) intact while flexing to different sizes.

## How David uses it

Recurring thread across videos:

- **Tolerance video** ([[videos/borrow-a-tolerance-mindset-for-designers]]) — David's HDPE hinge bracket is parametric; change one feature and the whole part re-fits. He promises future content on parametric CAD in his list of reader-requested topics.
- **Labels video** ([[videos/label-supplies-to-multiply-results]]) — a parametric M6 gauge block can be re-printed at M5 / M8 / etc. in minutes, making it cheap to equip a shop with size-checking tools without buying calipers for every station.
- **Extrusions video** ([[videos/aluminum-extrusions-fundamentals]]) — the 3D-printable rollerblade-wheel bracket and hinge on [[entities/brands/grabcad|GrabCAD]] are parametric so users can adjust hole spacing or wheel diameter themselves.

## Why it matters

Combined with [[concepts/borrowing-tolerances|borrowing tolerances]] and open-source publishing, parametric design lets one model become the seed for dozens of user-adapted variations. Central to the [[entities/projects/scuttle-robot|SCUTTLE]] design ethos.

## Related

- [[concepts/borrowing-tolerances]]
- [[entities/brands/grabcad]]
- [[entities/brands/solidworks]]

## Appears in

- [[videos/borrow-a-tolerance-mindset-for-designers]]
- [[videos/label-supplies-to-multiply-results]]
- [[videos/aluminum-extrusions-fundamentals]]
