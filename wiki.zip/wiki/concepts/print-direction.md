---
type: concept
aliases: [print orientation, layer direction]
tags: [3d-printing, fdm, design-for-manufacture]
source_count: 1
---

# Print direction

## Definition

The orientation of a part on the printer's build plate determines the direction of layer lines. Because FDM parts are weaker along the layer-separation axis, part orientation is a first-order design decision, not a printing preference.

## How David uses it

In [[videos/borrow-a-tolerance-mindset-for-designers]], David points out that loaded press-fit holes must be perpendicular to print lines. A shaft going through a hole whose axis parallels the print lines will split the part along the layers under side load; a shaft whose axis is perpendicular to the layers spreads contact over many layers and resists splitting.

This is cited as a baked-in design feature of [[entities/projects/scuttle-robot|SCUTTLE]] parts — "every single part of design for 3D printing such as the consideration for the print direction while we're achieving strength etc."

## Related

- [[entities/tools/3d-printer]]
- [[concepts/plastic-compressibility]]
- [[concepts/borrowing-tolerances]]

## Appears in

- [[videos/borrow-a-tolerance-mindset-for-designers]]
