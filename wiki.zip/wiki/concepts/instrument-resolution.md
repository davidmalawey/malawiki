---
type: concept
aliases: [measurement range, right-sized instrument]
tags: [measurement, engineering-method]
source_count: 1
---

# Instrument resolution

## Definition

An instrument rated for a much larger range than what you're measuring gives you noisy, imprecise readings. The right instrument is sized to the same order of magnitude as the quantity you care about.

## How David uses it

In [[videos/more-about-usb-than-you-ever-wanted-to-know]], David demonstrates by plugging a 5V / ~1W USB charger into a kilowatt-hour AC power meter. The readout shows "0 amps" and "0.1 watts" — a rounding-error-dominated reading because the instrument is rated for thousands of watts, not tens. A ~$5 USB power meter rated for 1-20V gives genuinely usable readings for the same task.

"You always want to come down to a device in the same range as what you're measuring."

## Related

- [[entities/tools/usb-power-meter]]

## Appears in

- [[videos/more-about-usb-than-you-ever-wanted-to-know]]
