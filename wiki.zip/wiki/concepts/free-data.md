---
type: concept
aliases: [free information, traces manufacturers leave]
tags: [lab-management, procurement, research]
source_count: 1
---

# Free data

## Definition

Information that already exists on the labels, manuals, and metadata around parts and tools — which you can read and use without paying for research. David treats this as dual to [[concepts/borrowing-tolerances|borrowing tolerances]]: instead of borrowing precision, you borrow *knowledge* the manufacturer accidentally published.

## How David uses it

From [[videos/label-supplies-to-multiply-results]]:

- **Copyright dates on labels** — a sandpaper advertised as "new technology" with a 1995 copyright on the back probably isn't new.
- **Safety-standard references** — a tool that requires "3M mask or ASM-compliant" tells you any $10 ASM-compliant respirator substitutes for the $50 3M one.
- **Compatibility manuals** — the cheap replacement filter listed in a vacuum's manual is often the same part as the name-brand "original" and is never listed on the product website.
- **Product manuals themselves** — often not available online because companies deliberately don't host them; the one that shipped in the box is the only copy.

## Related

- [[concepts/borrowing-tolerances]]
- [[concepts/calibrate-the-humans]]
- [[concepts/5s-methodology]]

## Appears in

- [[videos/label-supplies-to-multiply-results]]
