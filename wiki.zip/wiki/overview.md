---
type: overview
updated: 2026-04-24
video_count: 5
---

# Overview

A rolling synthesis of what this wiki covers. Updates with every ingest.

## The channel

David Malawey's YouTube channel. Craft / how-to / mechanical-engineering content aimed at hobbyists and students, especially those working in mechatronics, multidisciplinary engineering, and open-source robotics. David is formally a mechanical engineer — formative internship at [[entities/brands/toyota|Toyota]] in Georgetown, Kentucky — now teaching and running a lab at [[entities/brands/texas-am|Texas A&M]] and shepherding the open-source [[entities/projects/scuttle-robot|SCUTTLE]] robot platform.

His videos are deliberately built as **reference content you can jump around in**, not linear watches. Most are 20-70 minutes and catalog-shaped (20 tapes, 4 nut types, 10 cables cut open, 5 ways a ball helps an assembly). Engagement concentrates on videos that read like reference manuals.

## What's in the wiki so far

5 long-form videos ingested, ranging 24 minutes to 70 minutes, totaling ~3.5 hours of content.

| Date | Video | Theme |
|---|---|---|
| 2024-07-17 | [[videos/more-than-you-ever-wanted-to-know-about-tape\|Tape reference]] | Materials catalog |
| 2024-07-25 | [[videos/more-about-usb-than-you-ever-wanted-to-know\|USB deep-dive]] | Electronics teaching |
| 2024-08-15 | [[videos/borrow-a-tolerance-mindset-for-designers\|Borrow a Tolerance]] | Design mindset |
| 2024-08-31 | [[videos/label-supplies-to-multiply-results\|Label supplies]] | Lab organization |
| 2025-09-03 | [[videos/aluminum-extrusions-fundamentals\|Aluminum extrusions]] | Fabrication reference |

## Recurring themes

**"Borrow it instead of building it."** David's signature move is leveraging mass-produced precision — [[entities/tools/ball-bearings|ball bearings]], [[entities/materials/spring-steel|spring steel]], [[entities/materials/hdpe|HDPE]] tubing, paraffin wax, a golf tee — rather than machining to spec. [[concepts/borrowing-tolerances|Borrowing tolerances]] is the central concept; [[concepts/free-data|free data]] from labels and manuals is the information-shaped version of the same idea.

**Toyota-as-teacher.** Three separate videos invoke [[entities/brands/toyota|Toyota]] for a distinct lesson: [[concepts/5s-methodology|5S labeling]] (labels video), "if the customer has a problem we have a problem" (USB video), and real-world assembly design (tolerance video).

**Open-source parametric design.** Everything David builds is [[concepts/parametric-design|parametric]] and published on [[entities/brands/grabcad|GrabCAD]]. The [[entities/projects/scuttle-robot|SCUTTLE]] robot is the explicit project; the same ethos underlies the extrusion brackets.

**Named student-project mistakes.** Each teaching video calls out a "most common error I see" — drawing actuator current from an Arduino 5V pin (USB), bottoming a screw in an extrusion's slot (extrusions), designing your own charging circuit instead of buying a LiPo module (USB).

**Deliberate inefficiency in filming.** David acknowledges editing errors, speculates on details he's not certain of, and says so on camera — it's part of his teaching voice, not a flaw.

## Material, tool, and concept clusters

- **Plastics family** — [[entities/materials/hdpe|HDPE]], [[entities/materials/nylon|nylon]], [[entities/materials/urethane|urethane]], [[entities/materials/pla|PLA]], [[entities/materials/abs|ABS]], [[entities/materials/vinyl|vinyl]] recur for their distinct mechanical properties.
- **[[entities/materials/aluminum|Aluminum]]** threads through three videos in three roles: foil tape, cast engine block, structural extrusion.
- **Shop staples** — [[entities/tools/sharpie|Sharpie]] (3 videos), [[entities/tools/circular-saw|circular saw]] (2), [[entities/tools/3d-printer|3D printer]] (2).
- **Core concepts** — [[concepts/borrowing-tolerances|borrowing tolerances]], [[concepts/parametric-design|parametric design]], [[concepts/screw-as-spring|screw as a spring]], [[concepts/5s-methodology|5S]].

## Open threads

- **USB-C / Power Delivery deep-dive** promised at the end of the USB video but not yet published or ingested. Flag on next channel check.
- **David's three-jaw-chuck centering mechanism** — in development at the time of the tolerance video, to be open-sourced. Worth checking for a follow-up build video.
- **Scuttle design library** — extensive enough that a dedicated [[entities/projects/scuttle-robot|SCUTTLE]] series page may be warranted once 2-3 more SCUTTLE-centric videos are ingested.
- **Future parametric-CAD content** — David explicitly invited viewer feedback on which aspects of parametric design to cover next.
