---
type: entity
kind: material
aliases: []
first_seen: "[[videos/more-than-you-ever-wanted-to-know-about-tape]]"
tags: [plastic, low-friction]
source_count: 3
---

# Nylon

Recurring plastic across three videos, primarily for its non-stick and low-friction properties:

- Used as a non-sticky backing to cut shaped tape pieces without losing tackiness ([[videos/more-than-you-ever-wanted-to-know-about-tape]]).
- Mentioned as a low-friction alternative material for ball-bearing balls when abrasion-free contact is needed ([[videos/borrow-a-tolerance-mindset-for-designers]]).
- Called out as a container material that *doesn't* hold label adhesive well — part of why labels need modular, removable holders ([[videos/label-supplies-to-multiply-results]]).

## Appears in

- [[videos/more-than-you-ever-wanted-to-know-about-tape]]
- [[videos/borrow-a-tolerance-mindset-for-designers]]
- [[videos/label-supplies-to-multiply-results]]

## Related

- [[entities/materials/hdpe]]
