---
type: entity
kind: material
aliases: [ABS plastic]
first_seen: "[[videos/borrow-a-tolerance-mindset-for-designers]]"
tags: [plastic, 3d-printing-filament, tough]
source_count: 1
---

# ABS

Acrylonitrile butadiene styrene. Among the common FDM filaments (ABS, [[entities/materials/pla|PLA]], PETG), ABS is the toughest per [[videos/borrow-a-tolerance-mindset-for-designers]] — but tables often show [[entities/materials/hdpe|HDPE]] beating ABS for toughness. Used as the illustrative material in David's spring-feature discussion: ABS spring features still aren't deterministic because filament-to-filament and print-to-print variation dominates.

## Appears in

- [[videos/borrow-a-tolerance-mindset-for-designers]]
