---
type: entity
kind: material
aliases: [polylactic acid]
first_seen: "[[videos/borrow-a-tolerance-mindset-for-designers]]"
tags: [plastic, 3d-printing-filament]
source_count: 1
---

# PLA

Common FDM 3D-printing filament. David compares it to [[entities/materials/abs|ABS]] and PETG in [[videos/borrow-a-tolerance-mindset-for-designers]]: ABS is noticeably tougher than PLA or PETG, and [[entities/materials/hdpe|HDPE]] beats all three. PLA is treated as the common baseline filament, with [[concepts/plastic-compressibility|slight compression]] under a drill pass — which is why David sizes 8 mm nominal holes to 8.03 mm.

## Appears in

- [[videos/borrow-a-tolerance-mindset-for-designers]]

## Related

- [[entities/materials/abs]]
