---
type: entity
kind: material
aliases: [Al, aluminum alloy]
first_seen: "[[videos/more-than-you-ever-wanted-to-know-about-tape]]"
tags: [metal, structural, thermal, reflective]
source_count: 3
---

# Aluminum

Recurring material across three distinct roles in David's videos:

- **Aluminum foil tape** ([[videos/more-than-you-ever-wanted-to-know-about-tape]]) — reflective to infrared (disrupts [[concepts/emissivity|IR temperature measurements]]), electrically conductive (problematic for thermocouples picking up EMF from motors but useful as shielding), and conformable enough to hug contours for marking holes in fragile materials.
- **Cast aluminum for engine blocks and brackets** ([[videos/borrow-a-tolerance-mindset-for-designers]]) — cast surfaces are *not* precise; parts need to be post-machined at a datum to achieve flat gasket surfaces or perpendicular shaft holes.
- **T-slot aluminum extrusion** ([[videos/aluminum-extrusions-fundamentals]]) — 2020 and 3030 profiles are David's primary structural stock for frames, racks, and test rigs. Anodizing (gray or black) is a hard ceramic surface insulator — you have to scuff it to get electrical contact.

Aluminum is soft enough to hand-file and to cut with a wood blade (when lubricated with [[entities/materials/paraffin-wax|paraffin wax]]).

## Appears in

- [[videos/more-than-you-ever-wanted-to-know-about-tape]]
- [[videos/borrow-a-tolerance-mindset-for-designers]]
- [[videos/aluminum-extrusions-fundamentals]]

## Related

- [[concepts/emissivity]]
- [[entities/materials/paraffin-wax]]
