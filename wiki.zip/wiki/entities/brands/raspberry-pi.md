---
type: entity
kind: brand
aliases: [RPi]
first_seen: "[[videos/more-about-usb-than-you-ever-wanted-to-know]]"
tags: [single-board-computer]
source_count: 1
---

# Raspberry Pi

Single-board computer. Referenced in [[videos/more-about-usb-than-you-ever-wanted-to-know]] as a more sophisticated board than an Arduino because the RPi 3 has *two* independent USB buses, vs a single shared bus on a simpler board.

## Appears in

- [[videos/more-about-usb-than-you-ever-wanted-to-know]]
