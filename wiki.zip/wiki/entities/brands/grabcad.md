---
type: entity
kind: brand
aliases: []
first_seen: "[[videos/borrow-a-tolerance-mindset-for-designers]]"
tags: [cad, open-source, design-sharing]
source_count: 2
---

# GrabCAD

The CAD design-sharing platform where David publishes his open-source brackets, the [[entities/projects/scuttle-robot|SCUTTLE]] parts, and his parametric aluminum-extrusion accessories. Mentioned as the practical distribution point for the downloadable designs that tie his videos to hands-on projects.

## Appears in

- [[videos/borrow-a-tolerance-mindset-for-designers]]
- [[videos/aluminum-extrusions-fundamentals]]

## Related

- [[entities/projects/scuttle-robot]]
- [[entities/brands/solidworks]]
