---
type: entity
kind: brand
aliases: [Solid Works, SolidWorks]
first_seen: "[[videos/aluminum-extrusions-fundamentals]]"
tags: [cad, software]
source_count: 1
---

# Solid Works

CAD software. In [[videos/aluminum-extrusions-fundamentals]] David demonstrates the weldments workflow: draw a 3D sketch, attach custom extrusion profiles (his cleaned-up 3030 version 5 is a library feature to drag into the `Solid Works data/weldment profiles` directory), and generate a complete cut list with mitered joints without building a full multi-part assembly.

## Appears in

- [[videos/aluminum-extrusions-fundamentals]]

## Related

- [[entities/brands/grabcad]]
