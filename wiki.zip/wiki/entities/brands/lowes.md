---
type: entity
kind: brand
aliases: [Lowe's]
first_seen: "[[videos/aluminum-extrusions-fundamentals]]"
tags: [supplier, hardware-store]
source_count: 1
---

# Lowe's

Hardware store mentioned interchangeably with [[entities/brands/home-depot|Home Depot]] as the source of $2-3 USA-made steel handy boxes that mount to aluminum extrusion.

## Appears in

- [[videos/aluminum-extrusions-fundamentals]]
