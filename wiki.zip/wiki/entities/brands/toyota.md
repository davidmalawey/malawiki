---
type: entity
kind: brand
aliases: [Toyota Motor]
first_seen: "[[videos/more-about-usb-than-you-ever-wanted-to-know]]"
tags: [employer, formative, manufacturing]
source_count: 3
---

# Toyota

David's formative employer. His first internship was at [[entities/places/toyota-georgetown-kentucky|Toyota Georgetown]] (Kentucky), the largest Toyota plant in the US. Toyota shows up across his videos as the source of three distinct lessons:

1. **[[concepts/5s-methodology|5S methodology]]** — where he first encountered labels that seemed absurd ("chair" on a chair) and took years to appreciate ([[videos/label-supplies-to-multiply-results]]).
2. **"If the customer has a problem, we have a problem"** — invoked to explain why Apple polices its own cable quality ([[videos/more-about-usb-than-you-ever-wanted-to-know]]).
3. **Assembly-level design thinking** — not taught in his 6-year engineering curriculum but learned at Toyota, and the origin of his [[concepts/borrowing-tolerances|"borrow a tolerance"]] mindset ([[videos/borrow-a-tolerance-mindset-for-designers]]).

## Appears in

- [[videos/more-about-usb-than-you-ever-wanted-to-know]]
- [[videos/borrow-a-tolerance-mindset-for-designers]]
- [[videos/label-supplies-to-multiply-results]]

## Related

- [[entities/places/toyota-georgetown-kentucky]]
- [[concepts/5s-methodology]]
