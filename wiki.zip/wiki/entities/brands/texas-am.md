---
type: entity
kind: brand
aliases: [Texas A&M, TAMU]
first_seen: "[[videos/label-supplies-to-multiply-results]]"
tags: [university, workplace]
source_count: 1
---

# Texas A&M

The university where David currently works. Explicitly named in [[videos/label-supplies-to-multiply-results]] as the lab where he implements his [[concepts/5s-methodology|5S]] and labeling practices. The "student projects" and "Capstone design" references sprinkled through his other videos likely come from this context.

## Appears in

- [[videos/label-supplies-to-multiply-results]]

## Related

- [[entities/places/texas-am-lab]]
