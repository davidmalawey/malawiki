---
type: entity
kind: brand
aliases: []
first_seen: "[[videos/more-than-you-ever-wanted-to-know-about-tape]]"
tags: [supplier, marketplace]
source_count: 3
---

# Amazon

David's go-to marketplace for cheap-but-adequate parts. Called out specifically for: [[entities/materials/kapton-tape|Kapton tape]] at ~$8/roll (vs $30 for data-sheet-certified), 2020 aluminum extrusion (cheaper than on specialty suppliers because small 3D printers use it), and the small breakout boards / USB power meters he uses for teaching.

## Appears in

- [[videos/more-than-you-ever-wanted-to-know-about-tape]]
- [[videos/more-about-usb-than-you-ever-wanted-to-know]]
- [[videos/aluminum-extrusions-fundamentals]]
