---
type: entity
kind: brand
aliases: []
first_seen: "[[videos/more-than-you-ever-wanted-to-know-about-tape]]"
tags: [supplier, hardware-store]
source_count: 2
---

# Home Depot

Hardware store referenced as a source for aluminum foil tape (tape video) and $2-3 USA-made steel handy boxes that bolt onto aluminum extrusion with M6 fasteners (extrusions video). Lowe's is mentioned interchangeably.

## Appears in

- [[videos/more-than-you-ever-wanted-to-know-about-tape]]
- [[videos/aluminum-extrusions-fundamentals]]

## Related

- [[entities/brands/lowes]]
