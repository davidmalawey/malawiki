---
type: entity
kind: person
aliases: [David]
first_seen: "[[videos/more-than-you-ever-wanted-to-know-about-tape]]"
tags: [host, mechanical-engineering, mechatronics]
source_count: 5
---

# David Malawey

Host of the channel. Mechanical engineer and educator with a mechatronics and multidisciplinary-engineering focus. Formative early-career experience at [[entities/brands/toyota|Toyota]] (first internship at the Georgetown, Kentucky plant; later worked there). Currently teaches at [[entities/brands/texas-am|Texas A&M]] and leads the [[entities/projects/scuttle-robot|SCUTTLE]] open-source robot project.

## Recurring themes in his content

- Bridging the gap between textbook engineering and how assemblies actually get built in the real world
- Open-source, [[concepts/parametric-design|parametric]] design shared on [[entities/brands/grabcad|GrabCAD]]
- Pragmatic, observation-driven design — [[concepts/borrowing-tolerances|borrow tolerances]] from off-the-shelf parts rather than manufacturing them yourself
- Teaching via reference videos that viewers can jump around in (rather than watch linearly)
- Explicitly naming student-project failure modes ("the most common error I see…")

## Appears in

- [[videos/more-than-you-ever-wanted-to-know-about-tape]]
- [[videos/more-about-usb-than-you-ever-wanted-to-know]]
- [[videos/borrow-a-tolerance-mindset-for-designers]]
- [[videos/label-supplies-to-multiply-results]]
- [[videos/aluminum-extrusions-fundamentals]]

## Related

- [[entities/projects/scuttle-robot]]
- [[entities/brands/toyota]]
- [[entities/brands/texas-am]]
