---
type: entity
kind: tool
aliases: []
first_seen: "[[videos/aluminum-extrusions-fundamentals]]"
tags: [cutting, shop-tool]
source_count: 1
---

# Miter saw

David's primary tool for cutting aluminum T-slot extrusion, shown in [[videos/aluminum-extrusions-fundamentals]]. A standard wood blade works if you feed a piece of [[entities/materials/paraffin-wax|paraffin wax]] alongside the cut so the blade teeth stay lubricated and don't accumulate aluminum. Same technique produces factory-quality cuts on magnesium.

## Appears in

- [[videos/aluminum-extrusions-fundamentals]]

## Related

- [[entities/tools/circular-saw]]
