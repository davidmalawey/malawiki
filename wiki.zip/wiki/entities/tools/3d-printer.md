---
type: entity
kind: tool
aliases: [FDM printer]
first_seen: "[[videos/borrow-a-tolerance-mindset-for-designers]]"
tags: [prototyping, fdm, fabrication]
source_count: 2
---

# 3D printer

FDM printers run through David's content as a primary prototyping tool. Recurring points:

- The printer's **alignment** (perpendicularity) can be trusted; its **surface finish** cannot, so load-bearing holes need a drill pass — David uses an 8.03 mm bit for an 8 mm nominal hole to allow for [[concepts/plastic-compressibility|plastic compression]] ([[videos/borrow-a-tolerance-mindset-for-designers]]).
- Printing the same file with the same filament spool can still produce different mechanical properties — spring features are not deterministic on FDM.
- [[concepts/print-direction|Print orientation]] matters: loaded holes should be perpendicular to print lines.
- For lab sorting, a printed M6 gauge block is cheaper and faster than buying enough [[entities/tools/calipers|calipers]] to distribute across the shop ([[videos/label-supplies-to-multiply-results]]).

## Appears in

- [[videos/borrow-a-tolerance-mindset-for-designers]]
- [[videos/label-supplies-to-multiply-results]]

## Related

- [[concepts/print-direction]]
- [[concepts/plastic-compressibility]]
- [[entities/projects/scuttle-robot]]
