---
type: entity
kind: tool
aliases: [USB meter]
first_seen: "[[videos/more-about-usb-than-you-ever-wanted-to-know]]"
tags: [electronics, measurement]
source_count: 1
---

# USB power meter

Inline $5-10 USB-pass-through meter that reads voltage, current, and accumulated mAh. In [[videos/more-about-usb-than-you-ever-wanted-to-know]], David shows that its real value is the milliamp-hour integration over time — you can't trust a single-moment amp reading on variable-load devices. Rated for ~1-20V, so it's right-sized for USB; kilowatt-hour AC meters used for the same job are off by 10-20%.

## Appears in

- [[videos/more-about-usb-than-you-ever-wanted-to-know]]

## Related

- [[concepts/instrument-resolution]]
