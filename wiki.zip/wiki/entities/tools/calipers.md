---
type: entity
kind: tool
aliases: []
first_seen: "[[videos/borrow-a-tolerance-mindset-for-designers]]"
tags: [measurement]
source_count: 1
---

# Calipers

Precision measurement tool used in [[videos/borrow-a-tolerance-mindset-for-designers]] as the reference example of a "very precisely machined" instrument — David illustrates how you can [[concepts/borrowing-tolerances|borrow]] the calipers' tolerance by measuring one known ball, then use a golf tee to hold subsequent balls in a reliable relative position without needing to re-measure absolutely.

## Appears in

- [[videos/borrow-a-tolerance-mindset-for-designers]]
