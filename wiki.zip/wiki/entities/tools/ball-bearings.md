---
type: entity
kind: tool
aliases: [ball bearing, bearings]
first_seen: "[[videos/borrow-a-tolerance-mindset-for-designers]]"
tags: [precision-component, motion]
source_count: 1
---

# Ball bearings

The archetypal example of [[concepts/borrowing-tolerances|borrowed precision]] in [[videos/borrow-a-tolerance-mindset-for-designers]]. Each ball costs about 3 cents and is manufactured to tolerances no hobbyist machining can match.

David enumerates five things balls do for an assembly: (1) nominal contact averaging over surface peaks, (2) team effort — multiple balls achieve what one can't, (3) distributed tolerancing — each ball's deviation is independent, so the center of the clamped item moves *less* than any single ball's deviation, (4) force distribution — the ball spreads force over area on the softer material, reducing pressure and deformation, (5) selective material properties — glass marble for electrical insulation, nylon for low friction, steel for rigidity.

## Appears in

- [[videos/borrow-a-tolerance-mindset-for-designers]]

## Related

- [[concepts/borrowing-tolerances]]
