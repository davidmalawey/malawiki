---
type: entity
kind: place
aliases: [Toyota Georgetown plant, TMMK]
first_seen: "[[videos/label-supplies-to-multiply-results]]"
tags: [manufacturing, formative]
source_count: 1
---

# Toyota Georgetown plant, Kentucky

The Toyota manufacturing plant in Georgetown, Kentucky — "biggest plant in the US" per David. Setting of his first internship and the site of the "this is 5S" chair-label anecdote in [[videos/label-supplies-to-multiply-results]]. This is also almost certainly the implicit referent whenever David says "at Toyota" in other videos.

## Appears in

- [[videos/label-supplies-to-multiply-results]]

## Related

- [[entities/brands/toyota]]
- [[concepts/5s-methodology]]
