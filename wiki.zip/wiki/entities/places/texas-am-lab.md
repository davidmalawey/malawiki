---
type: entity
kind: place
aliases: [Texas A&M lab, David's lab]
first_seen: "[[videos/label-supplies-to-multiply-results]]"
tags: [workshop, education, current]
source_count: 1
---

# Texas A&M lab

David's current workshop / lab space at [[entities/brands/texas-am|Texas A&M]] where he implements [[concepts/5s-methodology|5S]] practices, manages student projects, and produces much of the on-camera footage. Explicitly named in [[videos/label-supplies-to-multiply-results]]; implicit setting for the workshop scenes in the tape, USB, tolerance, and extrusions videos.

## Appears in

- [[videos/label-supplies-to-multiply-results]]

## Related

- [[entities/brands/texas-am]]
- [[entities/people/david-malawey]]
