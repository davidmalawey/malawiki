---
type: entity
kind: project
aliases: [SCUTTLE, Scuttle]
first_seen: "[[videos/borrow-a-tolerance-mindset-for-designers]]"
tags: [open-source, robot, 3d-printing, education]
source_count: 3
---

# SCUTTLE robot

An open-source educational robot platform David leads. Designs are published on [[entities/brands/grabcad|GrabCAD]] and the Scuttle website. Parts are specifically designed for 3D printing — with features like the wheel-bracket hole drilled to 8.03 mm after printing to account for [[concepts/plastic-compressibility|PLA compressibility]], and [[concepts/print-direction|print orientation]] chosen to put loaded holes perpendicular to print lines.

The Scuttle design philosophy ([[concepts/parametric-design|parametric]], open-source, minimal post-processing) is the underlying ethos of many of David's videos even when SCUTTLE isn't the explicit subject.

## Appears in

- [[videos/borrow-a-tolerance-mindset-for-designers]] — wheel-bracket example
- [[videos/label-supplies-to-multiply-results]] — the "Scuttle organization" as a source of lab-practice lessons
- [[videos/aluminum-extrusions-fundamentals]] — bracket designs that follow the same open-source pattern

## Related

- [[entities/brands/grabcad]]
- [[entities/people/david-malawey]]
- [[concepts/borrowing-tolerances]]
